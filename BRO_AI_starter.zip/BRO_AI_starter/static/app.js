const form = document.getElementById("chatForm");
const input = document.getElementById("messageInput");
const chatLog = document.getElementById("chatLog");
const statusText = document.getElementById("statusText");
const countEl = document.getElementById("messageCount");
const voiceStatus = document.getElementById("voiceStatus");
const connectionStatus = document.getElementById("connectionStatus");
const voiceOrb = document.getElementById("voiceOrb");
let count = 1;
let femaleVoiceOn = true;
let recognition = null;

function addMessage(text, role) {
  const row = document.createElement("div");
  row.className = `message ${role}`;
  if (role === "assistant") {
    const avatar = document.createElement("div");
    avatar.className = "mini-avatar";
    avatar.textContent = "✦";
    row.appendChild(avatar);
  }
  const bubble = document.createElement("div");
  bubble.className = "bubble";
  const p = document.createElement("p");
  p.textContent = text;
  bubble.appendChild(p);
  row.appendChild(bubble);
  chatLog.appendChild(row);
  chatLog.scrollTop = chatLog.scrollHeight;
  count++;
  countEl.textContent = String(count);
  return row;
}

function speak(text) {
  if (!femaleVoiceOn || !("speechSynthesis" in window)) return;
  window.speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = "en-IN";
  const voices = window.speechSynthesis.getVoices();
  const preferred = voices.find(v => /female|woman|zira|samantha|google.*english.*female|heera/i.test(v.name))
    || voices.find(v => /en-IN/i.test(v.lang))
    || voices.find(v => /en/i.test(v.lang));
  if (preferred) utterance.voice = preferred;
  utterance.rate = 1;
  utterance.pitch = 1.05;
  window.speechSynthesis.speak(utterance);
}

async function sendMessage(text) {
  const message = (text || "").trim();
  if (!message) return;
  addMessage(message, "user");
  input.value = "";
  statusText.textContent = "BRO is thinking...";
  connectionStatus.textContent = "Connecting";
  const thinking = addMessage("One moment, I'm thinking...", "assistant");
  try {
    const response = await fetch("/api/chat", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({message})
    });
    const data = await response.json();
    const p = thinking.querySelector(".bubble p");
    p.textContent = data.reply || "I didn't receive a reply. Please try again.";
    connectionStatus.textContent = (data.reply || "").includes("not connected yet") ? "Setup needed" : "Connected";
    statusText.textContent = "BRO is ready for your next message.";
    speak(p.textContent);
  } catch (error) {
    thinking.querySelector(".bubble p").textContent = "I couldn't reach the server. Make sure the BRO AI app is running, then try again.";
    statusText.textContent = "Server connection unavailable.";
    connectionStatus.textContent = "Offline";
  }
  chatLog.scrollTop = chatLog.scrollHeight;
}

form.addEventListener("submit", e => {
  e.preventDefault();
  sendMessage(input.value);
});
document.querySelectorAll("[data-prompt]").forEach(button => {
  button.addEventListener("click", () => sendMessage(button.dataset.prompt));
});
document.querySelectorAll(".nav-item").forEach(button => {
  button.addEventListener("click", () => {
    document.querySelectorAll(".nav-item").forEach(b => b.classList.remove("active"));
    button.classList.add("active");
    if (button.dataset.mode !== "Chat") sendMessage(`Switching to ${button.dataset.mode}. Help me get started with this feature.`);
  });
});
document.getElementById("searchPrompt").addEventListener("keydown", e => {
  if (e.key === "Enter") sendMessage(e.target.value);
});
document.getElementById("themeButton").addEventListener("click", () => document.body.classList.toggle("soft-glow"));
document.getElementById("voiceToggle").addEventListener("click", e => {
  femaleVoiceOn = !femaleVoiceOn;
  e.currentTarget.textContent = femaleVoiceOn ? "🔊 Female Voice: On" : "🔇 Voice: Off";
  if (!femaleVoiceOn && "speechSynthesis" in window) window.speechSynthesis.cancel();
});
document.getElementById("voiceShortcut").addEventListener("click", startListening);
document.getElementById("headerMic").addEventListener("click", startListening);
document.getElementById("voiceInput").addEventListener("click", startListening);

function startListening() {
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SpeechRecognition) {
    statusText.textContent = "Voice input isn't supported in this browser. Try a recent version of Chrome, or type your message.";
    voiceStatus.textContent = "Not supported";
    return;
  }
  if (recognition) {
    recognition.stop();
    recognition = null;
  }
  recognition = new SpeechRecognition();
  recognition.lang = "en-IN";
  recognition.interimResults = false;
  recognition.maxAlternatives = 1;
  recognition.onstart = () => {
    voiceOrb.classList.add("listening");
    voiceStatus.textContent = "Listening";
    statusText.textContent = "Listening... speak now.";
  };
  recognition.onresult = event => {
    const transcript = event.results[0][0].transcript;
    input.value = transcript;
    sendMessage(transcript);
  };
  recognition.onerror = () => {
    statusText.textContent = "Voice input had a problem. You can type your message instead.";
    voiceStatus.textContent = "Ready";
  };
  recognition.onend = () => {
    voiceOrb.classList.remove("listening");
    voiceStatus.textContent = "Ready";
  };
  recognition.start();
}
